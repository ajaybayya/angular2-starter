
const express = require('express');

const app = express();
const port = process.env.PORT || 3000;

/* User Defined Routes */
const startupRoutes = require('./routes/startup.route');
const researchReportsRoutes = require('./routes/research-reports.route');


/* Middleware */
app.use(express.json());
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});;


/* Register Routes */
app.use('/api/startup', startupRoutes);
app.use('/api/research-reports', researchReportsRoutes);

app.use('/', (req, res) => {
    res.json({ message: 'API demo application is up and running' });
});



/* App Server */
const server = app.listen(port, () => {
    const host = server.address().address
    const port = server.address().port
    console.log(`API server is listening at http://${host}:${port}`);
});
