
const express = require('express');
const router = express.Router();

const fileUtils = require('../utiils/file-io.utils');

// GET
router.get('/all', (req, res) => {
    res.send(fileUtils.getFileContent(__dirname + '/../data/research-reports.json'));
});

module.exports = router;
