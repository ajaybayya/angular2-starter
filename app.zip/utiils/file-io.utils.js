const fs = require('fs');

const fileUtils = {
    getFileContent: function (fileName) {
        const data = fs.readFileSync(fileName, 'utf8', (err, jsonString) => {
            if (err) {
                console.log('Error reading file from disk:', err);
                return { error: 'Error while reading file data' };
            }
            try {
                const jsonContent = JSON.parse(jsonString);
                return jsonContent
            } catch (err) {
                console.log('No data found');
                return {
                    message: 'No data found'
                }
            }
        });
        return data;
    }
}

module.exports = fileUtils;
