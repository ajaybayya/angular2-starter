export const ServiceAPI = {
  GET_STARTUP_URL: '/api/startup/all'
};
