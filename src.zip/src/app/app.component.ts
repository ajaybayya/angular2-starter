import { Component } from '@angular/core';
import { AppStoreService } from './core/services/app-store.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ui-demo-app';
  constructor(private appStore: AppStoreService) {
    console.log(appStore.startupInfo);
  }
}
