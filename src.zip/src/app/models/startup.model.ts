export interface LoggedinUserInfo {
  fn: string;
  ln: string;
  email: string;
  photo: string;
  title: string;
  status: string;
  division: string;
  entitlement: string;
}

export interface StartupInfo {
  user: LoggedinUserInfo;
  isAdmin: boolean;
  region: string;
}
