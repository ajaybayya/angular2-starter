import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedComponentsModule } from './shared/components/shared-components.module';
import { HomeModule } from './featured/home/home.module';
import { StartupService } from './core/services/startup.service';


/* App Initializer */
export function initStartup (startupService: StartupService) {
  return () => startupService.loadStartupDetails();
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    RouterModule,
    HttpClientModule,
    SharedComponentsModule,
    HomeModule,
    AppRoutingModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initStartup,
      deps: [StartupService],
      multi: true
    }
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
