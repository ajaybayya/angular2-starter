import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ServiceAPI } from 'app/constants/api.constants';
import { StartupInfo } from 'app/models/startup.model';
import { Observable } from 'rxjs';
import { AppStoreService } from './app-store.service';

@Injectable({
  providedIn: 'root',
})
export class StartupService {
  constructor(private http: HttpClient, private appStore: AppStoreService) {}

  private getStartupResource(): Observable<StartupInfo> {
    return this.http.get<StartupInfo>(ServiceAPI.GET_STARTUP_URL);
  }

  public loadStartupDetails(): Promise<any> {
    const _self = this;
    return new Promise((resolve, reject) => {
      this.getStartupResource().subscribe((resp: StartupInfo) => {
        _self.appStore.startupInfo = resp;
        this.hideStartupSpinner();
        resolve(1);
      }, (err: HttpErrorResponse) => {
        reject();
      });
    });
  }

  hideStartupSpinner() {
    try {
      const spinnerElem: any = document.querySelector('.startup-spinner');
      if(spinnerElem) {
        // document.body.removeChild(spinnerElem);
      }
    } catch(err) {}
  }
}
