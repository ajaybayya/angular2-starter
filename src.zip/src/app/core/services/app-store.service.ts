import { Injectable } from '@angular/core';
import { StartupInfo } from 'app/models/startup.model';

@Injectable({
  providedIn: 'root',
})
export class AppStoreService {
  private _startupInfo: StartupInfo;

  constructor() {
    this._startupInfo = {} as StartupInfo;
  }

  get startupInfo(): StartupInfo {
    return this._startupInfo;
  }

  set startupInfo(data: StartupInfo) {
    this._startupInfo = data;
  }
}
